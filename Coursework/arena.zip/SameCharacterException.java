
public class SameCharacterException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	SameCharacterException(String z){
		super(z);
	}
}
