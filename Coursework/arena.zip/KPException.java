
public class KPException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	KPException(String s){
		super(s);
	}
}
