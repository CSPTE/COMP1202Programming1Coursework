
public class ElectronicStudent extends Student {
	/**
	 * This character does not have any special ability but his other base statistics are max
	 * @param inputName - the name of the character
	 */
	public ElectronicStudent(String inputName) {
		super(inputName, 10, 10, 10, 10, 0);
		//name, hp, atk, def, spd, kp
	}
}
