
public class CharacterDeadException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	CharacterDeadException(String r){
		super(r);
	}
}
